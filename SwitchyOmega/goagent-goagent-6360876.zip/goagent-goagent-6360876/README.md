goagent 3.2.3 [http://git.io/goa](https://nodeload.github.com/goagent/goagent/legacy.zip/3.0)

## Issues
* https://code.google.com/p/goagent/issues/list

## Documents
|    |   |
| --------   | :----  |
| Simple Guide | https://github.com/goagent/goagent/blob/wiki/SimpleGuide.md |
| Graphic Guide | https://github.com/goagent/goagent/blob/wiki/InstallGuide.md |
| FAQ | https://github.com/goagent/goagent/blob/wiki/FAQ.md |
| Configurations | https://github.com/goagent/goagent/blob/wiki/ConfigIntroduce.md.ini |
| Spam List | https://github.com/goagent/goagent/blob/wiki/SpamList.md |
| History | https://github.com/goagent/goagent/blob/wiki/History.md |

## Code
| | |
| --------   | :----  |
| proxy.py | https://github.com/goagent/goagent |
| python27.exe | https://github.com/goagent/pybuild |
| goagent.exe | https://github.com/goagent/taskbar |

## License
 * [GNU GPL v2](http://www.gnu.org/licenses/old-licenses/gpl-2.0.html)
